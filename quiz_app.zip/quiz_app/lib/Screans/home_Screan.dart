import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:quiz_app/Widgets/answers.dart';

import '../Widgets/quistions.dart';

class HomeScrean extends StatefulWidget {
  const HomeScrean({Key? key}) : super(key: key);

  @override
  State<HomeScrean> createState() => _HomeScreanState();
}

int _questionIndex = 0;

answerQuestion() {
  if(_questionIndex == 1){
    _questionIndex=-1;
  }

  setState(() {
    _questionIndex += 1;
  });



  print(_questionIndex);

}

List quistionText = [
  "What\'s your favorite color?",
  " What\'s your favorite animal?"
];

class _HomeScreanState extends State<HomeScrean> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Colors.purple,
          title: Text(
            'QuizApp',
            style: GoogleFonts.cairo(
              fontWeight: FontWeight.bold,
              fontSize: 28,
            ),
          ),
        ),
        body: Column(
          children: [
            Quistion(quistion: quistionText[_questionIndex]),
            const Answers(answers: "Answer1", x: answerQuestion),
            const Answers(answers: 'Answer1', x: answerQuestion),
            const Answers(answers: "Answer1", x: answerQuestion),
            const Answers(answers: "Answer1", x: answerQuestion),
          ],
        ));
  }
}
